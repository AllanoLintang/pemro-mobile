package com.allano.nongki

data class LocationModel (
    val nama: String,
    val foto: String
)