package com.allano.nongki

import android.view.View
import com.allano.nongki.databinding.RecyclerViewRowBinding

private var binding: RecyclerViewRowBinding? = null
class ItemAdapter(private val  ) {
}